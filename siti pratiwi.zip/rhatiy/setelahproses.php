<?php
echo "Terima kasih atas partisipasi anda mengisi data diri<br>";
echo "<a href='tampilan.php'>Isi Data Diri</a><br>";
echo "<a href='lihat.php'>Lihat Data Diri</a><br>";
?>